#Nama = Hari Safira Setyawati
#NIM = 250441100028

print ("Selamat Datang di Kasir Toko Sembako Maju Jaya")

print (input("Masukkan jenis barang yang akan anda beli: "))
#Nama Barang
beras = 12000 
gula = 14000
minyak = 20000


total_belanja = beras + gula + minyak
print ("Total belanja sementara ", total_belanja)
diskon_1 = total_belanja * 0.1
print ("Anda mendapatkan diskon sebanyak 10%", diskon_1)
diskon_2 = total_belanja * 0 
diskon_3 = total_belanja * 0.05
