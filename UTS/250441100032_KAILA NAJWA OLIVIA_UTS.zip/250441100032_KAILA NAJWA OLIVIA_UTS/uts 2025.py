print("===== kasir toko sembako maju jaya=====")
#toko menyediakan jenis barang
beras = 12000
gula = 14000
minyak = 20000
while true:
    nama_barang =float(input("masukkan nama barang :"))
    jumlah_barang = float(input("masukkan jumlah barang"))


if total_belanja > 100000:
    diskon : 10/100
if total_belanja > 200000:
    diskon : 15/100
if total_belanja > 150000:
    diskon : 10/100

