adaLagi ="y"
while adaLagi == "y":
    beras = 12000
    gula = 14000
    minyak = 20000
    memberCard = 0.05


    ada = "y"
    while ada =="y":
        n = (input("masukan barang: "))
        h = int(input("masukkan harga: "))
        j = int(input("jumlah: "))
        for i in ada:
            harga = h * j
    l = print(input("apakah ada barang lagi, tekan(y,n): ")).lower()
    if l == "y":
       print(ada)
    else:
        break

lagi=print(input("apakah ada pembeli lagi (y,n)")).lower()
if lagi == "y":
    print(adaLagi)