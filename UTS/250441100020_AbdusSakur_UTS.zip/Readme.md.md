pertama saya menggunakan variabel ada = "y" lalu while loop, lalu saya membuat inputan barang, harga, jumlah
kemudian saya membuat perulang for i in ada